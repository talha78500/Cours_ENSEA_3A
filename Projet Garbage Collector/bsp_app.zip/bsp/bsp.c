/* ======================================================================
 *  bsp.c : tout ce qui touche au HAL / a la carte Nucleo-L476RG.
 *  100 % interruptions : aucune boucle d'attente, aucun polling.
 *
 *  Chaine d'une mesure ToF (tout en IT) :
 *    GPIO1 du capteur (front descendant)  -> EXTI  -> Mem_Read_IT (2 octets @0x1E)
 *    fin de lecture I2C (RxCplt)          -> push EVT_TOF_DISTANCE
 *                                         -> Mem_Write_IT (0x0B <- 0x01, efface l'IT)
 * ====================================================================== */
#include "bsp.h"
#include "main.h"          /* B1_Pin, LD2_Pin, TOF_INT_Pin, MX_I2C1_Init ... */
#include "vl53l0x.h"
#include <string.h>

extern I2C_HandleTypeDef  hi2c1;
extern UART_HandleTypeDef huart2;

#ifndef TOF_INT_Pin
#error "Dans CubeMX : mets le label TOF_INT sur la broche reliee a GPIO1 du VL53L0X (mode GPIO_EXTI, front descendant)"
#endif

#define REG_RESULT_DIST        0x1E   /* 0x14 + 10 : distance, 2 octets, MSB d'abord */
#define REG_INTERRUPT_CLEAR    0x0B
#define UART_TX_SIZE           256
#define BUTTON_DEBOUNCE_MS     200

/* --- Etat prive du BSP (ce qui etait 'static' dans le cours) ----------- */
typedef struct bsp_ctx_struct {
    event_queue_t *events;
    vl53l0x_t      tof;
    bool           tof_running;
    uint8_t        tof_rx[2];
    uint8_t        tof_clear;

    uint8_t        tx_buf[UART_TX_SIZE];
    volatile uint16_t tx_head;
    volatile uint16_t tx_count;
    volatile bool     tx_busy;
    uint8_t        tx_byte;

    uint32_t       last_button_ms;
} bsp_ctx_t;

static bsp_ctx_t bsp_ctx;

/* --- Section critique (meme principe que dans event_queue.c) ------------ */
#define CRIT_ENTER()  uint32_t primask_ = __get_PRIMASK(); __disable_irq()
#define CRIT_EXIT()   __set_PRIMASK(primask_)

static void push(bsp_ctx_t *ctx, app_event_type_t type, int32_t data)
{
    if (ctx->events != NULL) {
        event_queue_push(ctx->events, (app_event_t){ .type = type, .data = data });
    }
}

/* ======================= UART TX par interruption ======================= */
/* Appelee avec les IT coupees ou depuis l'ISR TxCplt. */
static void uart_kick(bsp_ctx_t *ctx)
{
    if (ctx->tx_busy || ctx->tx_count == 0) return;
    ctx->tx_byte  = ctx->tx_buf[ctx->tx_head];
    ctx->tx_head  = (ctx->tx_head + 1) % UART_TX_SIZE;
    ctx->tx_count--;
    ctx->tx_busy  = true;
    if (HAL_UART_Transmit_IT(&huart2, &ctx->tx_byte, 1) != HAL_OK) {
        ctx->tx_busy = false;
    }
}

static void bsp_print(bsp_t *bsp, const char *s)
{
    bsp_ctx_t *ctx = (bsp_ctx_t *)bsp->ctx;
    CRIT_ENTER();
    while (*s && ctx->tx_count < UART_TX_SIZE) {      /* buffer plein : on tronque */
        uint16_t tail = (ctx->tx_head + ctx->tx_count) % UART_TX_SIZE;
        ctx->tx_buf[tail] = (uint8_t)*s++;
        ctx->tx_count++;
    }
    uart_kick(ctx);
    CRIT_EXIT();
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart != &huart2) return;
    bsp_ctx.tx_busy = false;
    uart_kick(&bsp_ctx);
}

/* ============================= LED / temps ============================== */
static void bsp_led_set(bsp_t *bsp, uint8_t led, bool on)
{
    (void)bsp;
    switch (led) {
        case 0: HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); break;
        default: break;
    }
}

static uint32_t bsp_get_tick_ms(bsp_t *bsp)
{
    (void)bsp;
    return HAL_GetTick();
}

/* ============================ Capteur ToF =============================== */
/* Demarrage : seul moment ou l'on accepte des appels bloquants (init ST). */
static bool tof_start(bsp_ctx_t *ctx)
{
    ctx->tof_running = false;

    if (HAL_I2C_IsDeviceReady(&hi2c1, VL53L0X_DEFAULT_ADDRESS_8BIT, 2, 50) != HAL_OK) return false;
    if (!VL53L0X_Init(&ctx->tof, &hi2c1))                                           return false;

    /* Portee longue (optionnel, valeurs Pololu non testees sur ton capteur) :
     * VL53L0X_SetSignalRateLimit(&ctx->tof, 0.1f);
     * VL53L0X_SetVcselPulsePeriod(&ctx->tof, VL53L0X_VCSEL_PERIOD_PRE_RANGE, 18);
     * VL53L0X_SetVcselPulsePeriod(&ctx->tof, VL53L0X_VCSEL_PERIOD_FINAL_RANGE, 14);
     * VL53L0X_SetMeasurementTimingBudget(&ctx->tof, 200000);                    */

    VL53L0X_StartContinuous(&ctx->tof, 0);

    /* Si GPIO1 etait deja a l'etat bas, aucun nouveau front ne viendrait :
     * on efface l'interruption et on purge un eventuel front en attente. */
    ctx->tof_clear = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, VL53L0X_DEFAULT_ADDRESS_8BIT, REG_INTERRUPT_CLEAR,
                      I2C_MEMADD_SIZE_8BIT, &ctx->tof_clear, 1, 20);
    __HAL_GPIO_EXTI_CLEAR_IT(TOF_INT_Pin);

    ctx->tof_running = true;
    return true;
}

static bool bsp_tof_restart(bsp_t *bsp)
{
    bsp_ctx_t *ctx = (bsp_ctx_t *)bsp->ctx;
    HAL_I2C_DeInit(&hi2c1);
    MX_I2C1_Init();
    bool ok = tof_start(ctx);
    if (ok) push(ctx, EVT_TOF_READY, 0);
    return ok;
}

/* 1) GPIO1 passe a 0 : une mesure est prete -> on lance la lecture en IT */
void HAL_GPIO_EXTI_Callback(uint16_t pin)
{
    bsp_ctx_t *ctx = &bsp_ctx;

    if (pin == TOF_INT_Pin) {
        if (!ctx->tof_running) return;
        if (HAL_I2C_Mem_Read_IT(&hi2c1, VL53L0X_DEFAULT_ADDRESS_8BIT, REG_RESULT_DIST,
                                I2C_MEMADD_SIZE_8BIT, ctx->tof_rx, 2) != HAL_OK) {
            push(ctx, EVT_TOF_ERROR, 0);               /* bus occupe : mesure ratee */
        }
    }
    else if (pin == B1_Pin) {
        uint32_t now = HAL_GetTick();
        if (now - ctx->last_button_ms >= BUTTON_DEBOUNCE_MS) {   /* anti-rebond */
            ctx->last_button_ms = now;
            push(ctx, EVT_BUTTON_CLICK, 0);
        }
    }
}

/* 2) Lecture terminee : on publie la distance, puis on efface l'IT du capteur */
void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    bsp_ctx_t *ctx = &bsp_ctx;
    if (hi2c != &hi2c1) return;

    uint16_t mm = (uint16_t)((ctx->tof_rx[0] << 8) | ctx->tof_rx[1]);
    push(ctx, EVT_TOF_DISTANCE, mm);

    ctx->tof_clear = 0x01;
    if (HAL_I2C_Mem_Write_IT(hi2c, VL53L0X_DEFAULT_ADDRESS_8BIT, REG_INTERRUPT_CLEAR,
                             I2C_MEMADD_SIZE_8BIT, &ctx->tof_clear, 1) != HAL_OK) {
        push(ctx, EVT_TOF_ERROR, 0);
    }
}

/* Erreur du bus I2C (NACK, arbitrage...) */
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c != &hi2c1) return;
    push(&bsp_ctx, EVT_TOF_ERROR, (int32_t)HAL_I2C_GetError(hi2c));
}

/* ============================== bsp_init ================================ */
void bsp_init(bsp_t *bsp, event_queue_t *events)
{
    memset(&bsp_ctx, 0, sizeof bsp_ctx);
    bsp_ctx.events = events;

    bsp->ctx         = (void *)&bsp_ctx;
    bsp->led_set     = bsp_led_set;
    bsp->print       = bsp_print;
    bsp->tof_restart = bsp_tof_restart;
    bsp->get_tick_ms = bsp_get_tick_ms;

    if (tof_start(&bsp_ctx)) {
        push(&bsp_ctx, EVT_TOF_READY, 0);
    } else {
        push(&bsp_ctx, EVT_TOF_ERROR, -1);      /* l'app decidera quoi faire */
    }
}
