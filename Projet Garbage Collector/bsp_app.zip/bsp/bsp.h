#ifndef BSP_H
#define BSP_H

#include <stdint.h>
#include <stdbool.h>
#include "event_queue.h"

/* ---------------------------------------------------------------------
 * bsp_t : l'INTERFACE (pointeurs de fonctions + ctx opaque).
 * app.c n'inclut que ce fichier : aucun HAL, aucun registre.
 * --------------------------------------------------------------------- */
typedef struct bsp_struct bsp_t;

struct bsp_struct {
    void *ctx;                                              /* etat prive du BSP   */
    void     (*led_set)(bsp_t *bsp, uint8_t led, bool on);  /* led 0 = LD2         */
    void     (*print)(bsp_t *bsp, const char *s);           /* UART, sans bloquer  */
    bool     (*tof_restart)(bsp_t *bsp);                    /* re-init du capteur  */
    uint32_t (*get_tick_ms)(bsp_t *bsp);
};

/* Branche l'interface sur l'implementation STM32, demarre le materiel
 * (UART, capteur ToF en mesures continues + interruption GPIO1) et
 * garde le pointeur vers la file d'evenements appartenant a l'app. */
void bsp_init(bsp_t *bsp, event_queue_t *events);

#endif /* BSP_H */
