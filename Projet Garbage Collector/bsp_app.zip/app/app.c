#include "app.h"
#include <stdio.h>

#define APP_NEAR_MM            150     /* seuil "objet proche"                   */
#define APP_OUT_OF_RANGE_MM    8190    /* >= : le capteur ne voit rien           */
#define APP_PRINT_PERIOD_MS    100     /* l'UART n'est pas la pour tout afficher */
#define APP_TOF_WATCHDOG_MS    1000    /* aucune mesure depuis 1 s -> relance    */
#define APP_TOF_MAX_RETRIES    5

void app_init(app_t *app, bsp_t *bsp)
{
    app->bsp = bsp;
    event_queue_init(&app->events);     /* AVANT que le BSP puisse pousser */

    app->last_mm       = 0;
    app->object_near   = false;
    app->verbose       = true;
    app->tof_running   = false;
    app->tof_retries   = 0;
    app->last_tof_ms   = 0;
    app->last_print_ms = 0;
}

static void on_distance(app_t *app, uint16_t mm)
{
    bsp_t *bsp = app->bsp;
    uint32_t now = bsp->get_tick_ms(bsp);
    char line[64];

    app->last_mm     = mm;
    app->last_tof_ms = now;
    app->tof_retries = 0;

    bool near = (mm < APP_NEAR_MM);
    if (near != app->object_near) {                 /* on ne touche la LED qu'au changement */
        app->object_near = near;
        bsp->led_set(bsp, 0, near);
    }

    if (app->verbose && (now - app->last_print_ms >= APP_PRINT_PERIOD_MS)) {
        app->last_print_ms = now;
        if (mm >= APP_OUT_OF_RANGE_MM) {
            snprintf(line, sizeof line, "Dist = hors portee\r\n");
        } else {
            snprintf(line, sizeof line, "Dist = %u mm (%u.%u cm)\r\n",
                     (unsigned)mm, (unsigned)(mm / 10), (unsigned)(mm % 10));
        }
        bsp->print(bsp, line);
    }
}

static void try_restart(app_t *app)
{
    bsp_t *bsp = app->bsp;

    if (app->tof_retries >= APP_TOF_MAX_RETRIES) {
        app->tof_running = false;
        bsp->print(bsp, "[ToF] Abandon apres plusieurs essais. Verifie le cablage.\r\n");
        return;
    }
    app->tof_retries++;
    bsp->print(bsp, "[ToF] Recovery: reset I2C1 + restart sensor...\r\n");
    bsp->tof_restart(bsp);          /* pousse EVT_TOF_READY si ca marche */
}

static void handle_event(app_t *app, const app_event_t *evt)
{
    bsp_t *bsp = app->bsp;

    switch (evt->type) {
    case EVT_TOF_READY:
        app->tof_running = true;
        app->last_tof_ms = bsp->get_tick_ms(bsp);
        bsp->print(bsp, "[ToF] VL53L0X initialized & continuous ranging started!\r\n");
        break;

    case EVT_TOF_DISTANCE:
        on_distance(app, (uint16_t)evt->data);
        break;

    case EVT_TOF_ERROR:
        try_restart(app);
        break;

    case EVT_BUTTON_CLICK:
        app->verbose = !app->verbose;
        bsp->print(bsp, app->verbose ? "[B1] affichage ON\r\n" : "[B1] affichage OFF\r\n");
        break;
    }
}

void app_process(app_t *app)
{
    app_event_t evt;
    while (event_queue_pull(&app->events, &evt)) {
        handle_event(app, &evt);
    }

    /* Chien de garde : si le capteur se tait (plus d'interruption GPIO1),
     * aucun evenement ne viendra nous le dire -> on compare les dates. */
    if (app->tof_running) {
        uint32_t now = app->bsp->get_tick_ms(app->bsp);
        if (now - app->last_tof_ms > APP_TOF_WATCHDOG_MS) {
            app->last_tof_ms = now;
            try_restart(app);
        }
    }
}
