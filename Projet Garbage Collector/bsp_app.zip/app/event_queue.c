#include "event_queue.h"

/* Section critique : push (appele depuis une ISR) et pull (appele depuis
 * main) modifient head/count. On coupe les interruptions pendant la
 * modification pour qu'une ISR ne voie jamais une file a moitie mise a jour.
 * Sur PC (simulateur) ce sont des no-op. */
#if defined(__arm__)
#include "stm32l4xx.h"
#define CRIT_ENTER()  uint32_t primask_ = __get_PRIMASK(); __disable_irq()
#define CRIT_EXIT()   __set_PRIMASK(primask_)
#else
#define CRIT_ENTER()  do {} while (0)
#define CRIT_EXIT()   do {} while (0)
#endif

void event_queue_init(event_queue_t *q)
{
    q->head  = 0;
    q->count = 0;
}

bool event_queue_push(event_queue_t *q, app_event_t evt)
{
    CRIT_ENTER();
    if (q->count >= EVENT_QUEUE_CAPACITY) {
        CRIT_EXIT();
        return false;                       /* file pleine : evenement perdu */
    }
    int tail = (q->head + q->count) % EVENT_QUEUE_CAPACITY;
    q->items[tail] = evt;
    q->count++;
    CRIT_EXIT();
    return true;
}

bool event_queue_pull(event_queue_t *q, app_event_t *out)
{
    CRIT_ENTER();
    if (q->count == 0) {
        CRIT_EXIT();
        return false;
    }
    *out = q->items[q->head];
    q->head = (q->head + 1) % EVENT_QUEUE_CAPACITY;
    q->count--;
    CRIT_EXIT();
    return true;
}
