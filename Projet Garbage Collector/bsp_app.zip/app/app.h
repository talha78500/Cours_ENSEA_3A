#ifndef APP_H
#define APP_H

#include <stdint.h>
#include <stdbool.h>
#include "bsp.h"            /* l'interface bsp_t seulement : aucun HAL ici */
#include "event_queue.h"

typedef struct {
    bsp_t        *bsp;
    event_queue_t events;        /* la file appartient a l'app (le consommateur) */

    /* etat applicatif */
    uint16_t last_mm;
    bool     object_near;        /* objet a moins de APP_NEAR_MM : LD2 allumee   */
    bool     verbose;            /* bouton B1 : affichage on/off                 */
    bool     tof_running;
    uint8_t  tof_retries;
    uint32_t last_tof_ms;        /* date de la derniere mesure (chien de garde)  */
    uint32_t last_print_ms;
} app_t;

/* app_init : prepare la file et l'etat. Le BSP n'est pas encore branche :
 * on ne fait que memoriser le pointeur. Ordre dans main :
 *     app_init(&app, &bsp);  bsp_init(&bsp, &app.events);                 */
void app_init(app_t *app, bsp_t *bsp);

/* Vide la file d'evenements (plus de polling : on traite ce qui est arrive) */
void app_process(app_t *app);

#endif /* APP_H */
