#ifndef EVENT_QUEUE_H
#define EVENT_QUEUE_H

#include <stdint.h>
#include <stdbool.h>

/* Evenements de l'application (le BSP les pousse, l'app les consomme).
 * Ce fichier ne depend d'AUCUN HAL : il compile aussi sur PC. */
typedef enum {
    EVT_TOF_READY,      /* capteur initialise, mesures en cours            */
    EVT_TOF_DISTANCE,   /* nouvelle mesure ; data = distance en mm         */
    EVT_TOF_ERROR,      /* erreur I2C / mesure manquee                     */
    EVT_BUTTON_CLICK    /* bouton bleu B1                                  */
} app_event_type_t;

typedef struct {
    app_event_type_t type;
    int32_t          data;
} app_event_t;

#define EVENT_QUEUE_CAPACITY 16

/* File FIFO = buffer circulaire : tableau + head + count */
typedef struct {
    app_event_t items[EVENT_QUEUE_CAPACITY];
    volatile int head;
    volatile int count;
} event_queue_t;

void event_queue_init(event_queue_t *q);
bool event_queue_push(event_queue_t *q, app_event_t evt);   /* false = file pleine */
bool event_queue_pull(event_queue_t *q, app_event_t *out);  /* false = file vide   */

#endif /* EVENT_QUEUE_H */
