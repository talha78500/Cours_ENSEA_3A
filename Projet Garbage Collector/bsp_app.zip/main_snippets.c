/* ===== A copier dans Core/Src/main.c (uniquement dans les USER CODE) ===== */

/* USER CODE BEGIN Includes */
#include "app.h"
#include "bsp.h"
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
static bsp_t bsp;
static app_t app;
/* USER CODE END PV */

/* ... apres MX_I2C1_Init(); MX_USART2_UART_Init(); ... */

/* USER CODE BEGIN 2 */
app_init(&app, &bsp);              /* file d'evenements + etat */
bsp_init(&bsp, &app.events);       /* branche l'interface, demarre UART + ToF */
/* USER CODE END 2 */

/* while (1) { */
/* USER CODE BEGIN 3 */
    app_process(&app);             /* traite les evenements arrives */
    __WFI();                       /* dort jusqu'a la prochaine interruption */
/* } */
/* USER CODE END 3 */
